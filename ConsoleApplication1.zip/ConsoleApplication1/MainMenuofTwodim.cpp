#include "Libraries.h"

void twoDimArrMenu()
{
	char choice = '0';
	float** Arr = NULL;
	int N;
	int n = 0;

	cout << "This is the menu for the Two Dimention Array! You can solve the next tasks:\n"
		<< "1 -> Enter data\n"
		<< "2 -> Display data\n"
		<< "3 -> Search local minimum\n";
	cout << "Make your choice -> ";
	cin >> choice;

	cout << "Enter the matrix' size -> ";
	cin >> n;

	Arr = new float* [n];
	for (int i = 0; i < n; i++)
		Arr[i] = new float[n];

	FillArr(n, Arr);


	switch (choice)
	{
	case '1':
		cout << "Enter the matrix' size -> ";
		cin >> n;

		Arr = new float* [n];
		for (int i = 0; i < n; i++)
			Arr[i] = new float[n];

		FillArr(n, Arr);
		break;
	case '2':
		DisplayArr(n, Arr);
		break;
	case '3':
		LocalMin(n, Arr);
		break;
	default:
		break;
	}

}