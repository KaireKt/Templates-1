#pragma once

//Commun functions
void onedim();

//One Dimention Array
void minEL(int*, int*, int);
void sum(int*, int*, int);
void convertarr(int*, int*, int);

//Two Dimention Array

void twoDimArrMenu();
void FillArr(int n, float** a);
void DisplayArr(int n, float** a);

void LocalMin(int n, float** a);
bool CheckMin(int i, int j, float** a, int n);

bool CheckArr(int a);