#include "Libraries.h"


void LocalMin(int n, float** a)
{
	int count = 0;
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; i < n; i++)
		{
			if (CheckMin(i, j, a, n))
			{
				if (count == 0)
				{
					cout << "Local minimums are here (" << i << ";" << j << ")";
					count++;
				}
				else
				{
					cout << ", (" << i << ";" << j << ") ";
					count++;
				}
			}
		}
	}
	if (count == 1)
		cout << endl << "There is " << count << " local minimum";
	else if (count != 0)
		cout << endl << "There are " << count << " local minimums";
	else if (count == 0)
		cout << endl << "There are not local minimums";
}

bool CheckMin(int i, int j, float** a, int n)
{
	float number = a[i][j];
	/*	if (i > 0 && number > a[i - 1][j]) return false;
		if (j > 0 && number > a[i][j - 1]) return false;
		if (i < (n - 1) && number > a[i + 1][j]) return false;
		if (j < (n - 1) && number > a[i][j + 1]) return false;
	*/
	if (i == 0 && j == 0 && number >= a[i + 1][j]) return false; // 00 - ������ �������� �������
	if (i == 0 && j == 0 && number >= a[i][j + 1]) return false; // 00
	if (i > 0 && i < (n - 1) && j == 0 && number >= a[i - 1][j]) return false; // 01
	if (i > 0 && i < (n - 1) && j == 0 && number >= a[i + 1][j]) return false; // 01
	if (i > 0 && i < (n - 1) && j == 0 && number >= a[i][j + 1]) return false; // 01
	if (i == n && j == 0 && number >= a[i - 1][j]) return false; // 02
	if (i == n && j == 0 && number >= a[i][j + 1]) return false; // 02
	if (i == 0 && j > 0 && j < n && number >= a[i + 1][j]) return false; // 10
	if (i == 0 && j > 0 && j < n && number >= a[i][j - 1]) return false; // 10
	if (i == 0 && j > 0 && j < n && number >= a[i][j + 1]) return false; // 10
	if (i > 0 && i < n && j > 0 && j < n && number >= a[i - 1][j]) return false; // 11
	if (i > 0 && i < n && j > 0 && j < n && number >= a[i + 1][j]) return false; // 11
	if (i > 0 && i < n && j > 0 && j < n && number >= a[i][j - 1]) return false; // 11
	if (i > 0 && i < n && j > 0 && j < n && number >= a[i][j + 1]) return false; // 11
	if (i == 0 && j > 0 && j < n && number >= a[i - 1][j]) return false; // 12
	if (i == 0 && j > 0 && j < n && number >= a[i][j + 1]) return false; // 12
	if (i == 0 && j > 0 && j < n && number >= a[i][j - 1]) return false; // 12
	if (i == 0 && j == n   && number >= a[i + 1][j]) return false; // 20
	if (i == 0 && j == n   && number >= a[i][j - 1]) return false; // 20
	if (i > 0 && i < n && j == n && number >= a[i + 1][j]) return false; // 21
	if (i > 0 && i < n && j == n && number >= a[i - 1][j]) return false; // 21
	if (i > 0 && i < n && j == n && number >= a[i][j - 1]) return false; // 21
	if (i == n && j == n && number >= a[i - 1][j]) return false; // 22
	if (i == n && j == n && number >= a[i][j - 1]) return false; // 22
	// ��������� ��� ������� �������� �������.
	return true;
}