#pragma once

#include<iostream>
#include<iomanip>

using namespace std;

//--------------

#include"prototypes.h"
